if (navigator.requestMIDIAccess) {
  console.log('This browser supports WebMIDI!');

  if (document.querySelector('body')) {
    document.querySelector('body').innerHTML = 'MIDI DEVICES FOUND';
  }
  // navigator.requestMIDIAccess({ sysex: true } ).then(onMIDISuccess, onMIDIFailure);
  navigator.requestMIDIAccess().then(onMIDISuccess, onMIDIFailure);
} else {
  console.log('WebMIDI is not supported in this browser.');
  document.querySelector('body').innerHTML = 'Error: This browser does not support WebMIDI.';
}

var midi = null;
var output = null;


function onMIDISuccess(midiAccess) {

  // document.querySelector('body').innerHTML = 'Press any note to begin...';

    midi = midiAccess;
    var inputs = midiAccess.inputs;
    var outputs = midiAccess.outputs;
    var lista = [];
    var devicesMap = new Map();
    let table = document.querySelector("table");

    for (var input of midiAccess.inputs.values()) {
      lista.push(input.name);
      devicesMap.set(input.id, input.name);
      if (input.name == "CONTROL PIE") {
        input.onmidimessage = getCTRLPIEmsg; // attach de un listener distinto para el dispositivo control pie
      } else {
        input.onmidimessage = getMIDIMessage; //attach de un litener generico de mensajes midi (util para hacer midi LEARN)
      }
    }

    for (out of midiAccess.outputs.values()) {
      if (out.name == "CONTROL PIE") {
        console.log(out.name);
        output = out;
        sendInitMsg();
        showCtrlPieConnected();
        sendKeepAlive();
        $('#btnAlertConnect').removeClass("invisible");
        $('#btnAlertConnect').removeClass("btn-warning");
        $('#btnAlertConnect').addClass("btn-success");
        $('#btnAlertConnect').text("CONTROL PIE CONECTADO!");
// $('#alertConnect').hide();

      } else {
        $('#btnAlertConnect').removeClass("invisible");
        // $('#btnAlertConnect').addClass("btn-warning");

        // no hay attach de eventos para otros outputs
// $('#alertConnect').show();
      }
    }



}

function showCtrlPieConnected() {

  $("#lowPanel").removeClass("invisible");


}


function generateTableHead(table, data) {
  let thead = table.createTHead();
  let row = thead.insertRow();
  for (let key of data) {
    let th = document.createElement("th");
    let text = document.createTextNode(key);
    th.appendChild(text);
    row.appendChild(th);
  }
}

function generateTable(table, data) {
  for (let element of data) {
    let row = table.insertRow();
    for (key in element) {
      let cell = row.insertCell();
      let text = document.createTextNode(element[key]);
      cell.appendChild(text);
    }
  }
}



function onMIDIFailure() {
  document.querySelector('.step0').innerHTML = 'Error: Could not access MIDI devices. Connect a device and refresh to try again.';
}

function getMIDIMessage(message) {
  var command = message.data[0];
  var note = message.data[1];
  var velocity = (message.data.length > 2) ? message.data[2] : null; // a velocity value might not be included with a noteOff command


  switch (true) { //un switch especial!!!
    case  ((command >= 144) && (command <= 159)): // noteOn
      if (velocity > 0) {
        noteOnListener(command & 0xf,note, velocity);
      } else {
        noteOffListener(note);
      }
      break;

      case  ((command >= 128) && (command <= 143)):
      noteOffCallback(note);
      break;
      default:
      console.log(command+" "+note+ " "+velocity);
      break;
      // we could easily expand this switch statement to cover other types of commands such as controllers or sysex
  }
}

var connectionStep = 0;
var dataCount = 0;
var allConfigData = new Array(493);

function getCTRLPIEmsg(message) {
  var header = message.data[0];
  var leftHalf = message.data[1];
  var rightHalf = (message.data.length > 2) ? message.data[2] : 0; // a rightHalf value might not be included with a leftHalfOff command


  switch (connectionStep) {
    case 0: //CTRL pie is connecting
      //ignores incomming messages in this stage
      console.log("ignoring..." + header.toString(16) + " " + leftHalf.toString(16) + " " + rightHalf.toString(16));
      break;
    case 1: // waiting for response token
      console.log("handshaking... " + header.toString(16) + " " + leftHalf.toString(16) + " " + rightHalf.toString(16));
      if (header == 0xBC && leftHalf == 0x1A && rightHalf == 0x70) {
        var msg2 = [0xBC, 0x1A, 0x7F]; // leftHalf on, middle C, full rightHalf
        console.log(msg2);
        output.send(msg2, window.performance.now() + 500.0);
        connectionStep++;
      }
      break;
    case 2: //receiving inital data config
      // console.log("data: "+dataCount + " " +header.toString(16) + " " + leftHalf.toString(16) + " " + rightHalf.toString(16));
      allConfigData[dataCount] = (((leftHalf & 0x0f) << 4) | (rightHalf & 0x0f)); //Stores read data

      dataCount++;
      console.log("data: " + pad(dataCount, 3) + " " + decimalToHex(header, 2) + " " + decimalToHex(leftHalf, 2) + " " + decimalToHex(rightHalf, 2) +
        " dec value: " + (((leftHalf & 0x0f) << 4) | (rightHalf & 0x0f)));


      if (dataCount == 493) {
        console.log("all data received ok");
        dataCount = 0;
        setRadioWithCurrentPreset(rightHalf);

        connectionStep++; // Handle timeout or any possible error.
      }
      break;
    case 3: //connected to Ctrol PIE
      // dataCount++;
      // console.log("data: " + pad(dataCount, 3) + " " + decimalToHex(header, 2) + " " + decimalToHex(leftHalf, 2) + " " + decimalToHex(rightHalf, 2) +        " dec value: " + (((leftHalf & 0x0f) << 4) | (rightHalf & 0x0f)));
      break;

  }



  if (header == 187 && rightHalf == 0) {
    var tx = "Boton " + leftHalf + " apretado momentaneamente.";
    document.querySelector('#btnRead').innerHTML = tx;
    console.log(tx);
  }
  if (header == 187 && rightHalf == 1) {
    var tx = "Boton " + leftHalf + " pulsado largo.";
    document.querySelector('#btnRead').innerHTML = tx;
    console.log(tx);
  }



  // if(command==187 && rightHalf == 2){
  // 	var tx = "Boton "+leftHalf+" soltado.";
  // 	document.querySelector('#btnRead').innerHTML = tx;
  // 	console.log(tx);
  // }


}


function noteOffCallback(note) {
  // alert("not off"+note);

}

function noteOnListener(channel, note, velocity) {
  $('#channel').html("Channel: " + channel);
  $('#notePressed').html("Note Pressed: " + note);
  $('#noteVelocity').html("Velocity: " + velocity);
}

function noteOffListener(note) {
  // document.querySelector('#noteReleased').innerHTML = note;
}

var CtrlPieIsConnected = false;

function sendInitMsg() {
  var msg1 = [0xBE, 0x1A, 0x70]; // BE	1A	70
  console.log("Connect request..." + msg1);
  output.send(msg1);
  connectionStep = 1;
}

function sendKeepAlive() {
  var msg1 = [0xB7, 0x70, 0x7F]; // note on, middle C, full velocity

  if (output) {
    output.send(msg1, );
    console.log("keep alive...");
  }
  setTimeout(sendKeepAlive, 5000);

}

function setRadioWithCurrentPreset(value) {
  console.log(value);
  $('input[id="option'+value+'"]').parent().addClass('active');
};

$(document).ready(function() { // ESTO PREVIENE QUE SE EJECUTEN ESTOS JQUERY ANTES DE QUE CARGUE LA PAGINA
  $('#btnAlertConnect').click(function() {
navigator.requestMIDIAccess().then(onMIDISuccess, onMIDIFailure);
    });

  $("#getConfig").click(function() {
    var msg1 = [0xBE, 0x1D, 0x70]; //BE	1D	70
    output.send(msg1);
  });

  $("#getActivePreset").click(function() {
    var msg1 = [0xBE, 0x1D, 0x70]; //BE	1D	70
    output.send(msg1);
  });

  $("#restoreToFactory").click(function() {
      var msg1 = [0xBE, 0x0F, 0x70]; //BE	0F	70
      output.send(msg1);
      $("#modalbody").text("Default values restored.");
      $("#restoreToFactory").addClass("disabled")
      $("#restoreToFactory").prop('disabled', true);
      // alert("Control Pie restored to factory default values");
  });

$("#restoreBtn").click(function() {
  console.log("sdsd");
  $("#restoreToFactory").removeClass("disabled")
  $("#restoreToFactory").prop('disabled', false);
});



  $(document).on('change', 'input:radio[id^="option"]', function (event) {
        presetSelected = $(this).val();
        var msg1 = [0xBF, 0x1C, presetSelected]; //BF	1C	06
        output.send(msg1);
        console.log(presetSelected);
    });



});


function decimalToHex(d, padding) {
  var hex = Number(d).toString(16);
  padding = typeof(padding) === "undefined" || padding === null ? padding = 2 : padding;

  while (hex.length < padding) {
    hex = "0" + hex;
  }

  return hex;
}

function pad(n, width, z) {
  z = z || '0';
  n = n + '';
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}



window.onunload = function() { //APP DISCONNECT message cuando se cierra
  var msg1 = [0xBE, 0x1F, 0x7F]; //BE	1F	7F
  output.send(msg1);
}
